# TUFAN All-Protections Plan Set

This index coordinates four independently testable implementation plans for the approved compatibility-preserving design. It is a roadmap only; it does not authorize source-code changes before the user reviews the plans and chooses an execution method.

## Approved design

All plans implement [the approved protection design](../specs/2026-10-20-tufan-all-protections-design.md). Compatibility is mandatory. Generic annotation encryption and package/component/manifest identity mangling are excluded and must never be represented as applied. Host tests can establish host behavior only; Android runtime and release success require the explicit release gates below.

## Plans and order

1. [Hybrid backend and protection verification](2026-10-20-tufan-hybrid-verification-plan.md) establishes exact fallback-body handling, immutable per-method C++/TKS VM/Java dispositions, JNI registration failure behavior, the typed report/verifier API, method-selection policy, and Dex2C result-typing regressions. It is the foundational interface plan.
2. [APK release integrity](2026-10-20-tufan-release-integrity-plan.md) consumes the typed report and request model from Plan 1. It validates ZIP/APK inputs and rebuilt invariants, signs only with a caller-supplied per-build key/certificate, verifies source/update identity and final signature, and blocks release success if signing or Android runtime verification is absent or fails.
3. [Compatibility-preserving transformations](2026-10-20-tufan-compatibility-transforms-plan.md) consumes the report/request types from Plan 1 and runtime gate from Plan 2. It adds default-off log removal, allowlisted private-method obfuscation, and an existing-Application-only crash hook; unsafe cases are unchanged and reported as skipped/unverified.
4. [Build optimization](2026-10-20-tufan-build-optimization-plan.md) runs after the preceding interfaces stabilize. It adds an immutable DEX index and grouped smali rewrites, using deterministic operation counts and semantic-equivalence tests rather than speculative timing claims.

Execute the plans sequentially in the order above. Within each plan, complete and verify every task before starting the next plan. The compatibility plan's Android crash-hook acceptance remains gated on the release plan's configured Android runtime matrix.

## Shared verification commands and status rules

The common host gate is:

```bash
./host-tests/gradlew -p host-tests clean test
```

A host pass does not establish Android installability, component behavior, runtime decryption, signing validity, or release eligibility. Missing Android device/ABI evidence remains `UNVERIFIED`; a failed requested release gate blocks output success. Explicitly unsigned development output is never `RELEASE_SUCCESS`.

Every task uses test-first RED → GREEN steps and derives counts/statuses from verified artifacts, not configuration flags. No key/password, mapping, plaintext payload, or sensitive raw path belongs in reports or normal logs. The supplied project archive has no Git metadata, so implementation must not claim commits that were not made.

## Completion

The plan set is complete only when every task in all four plans is checked after its stated verification, the full host suite passes, the final source ZIP is integrity-checked, and Android release status is honestly reported as blocked/unverified unless the required signing and runtime matrix was actually exercised.