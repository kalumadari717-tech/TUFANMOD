# TUFAN protection security notes

## What is implemented

The protection pipeline now uses versioned AES-GCM envelopes for transformed strings, VM method words, and the build manifest. Parsing validates fixed headers and declared lengths before reading payload data; invalid keys, contexts, truncated data, and authentication failures are rejected. JNI method-open failures preserve an existing Java exception, and a bridge failure without one raises `SecurityException` rather than silently executing a Java fallback or returning a primitive default.

The VM backend applies a deterministic, build-seeded basic-block layout transformation to the validated VM instruction subset. Branch targets and conditional fall-throughs are remapped, and the Java reference VM and native C++ VM are covered by host parity tests for the tested branch, loop, and fan-out cases.

Generated methods are reported in separate **C++**, **VM**, and **FALLBACK** categories. A signature is considered fully native only when the corresponding C++ or VM wrapper source was emitted successfully. Unsupported methods remain Java-body trampolines and are not counted as fully native. These counts describe generated source, not proof that an Android NDK build linked or that the resulting APK was executed.

The authenticated build manifest validates the expected build/module context and protected method membership. This is payload/build-context validation; it is **not whole-APK integrity verification**. The former fixed-byte JNI startup digest was removed because it did not verify an APK artifact.

## Security limits and release blockers

The 32-byte per-output key is generated for offline processing and is embedded in generated native code so the protected app can decrypt its data without a server. A determined analyst who controls the APK or runtime can recover that key. The envelopes provide authenticated stored-data protection and raise reverse-engineering cost; they do not make client-side secrets unrecoverable or make the application uncrackable.

DEX translation and VM execution cover conservative supported subsets only. Unsupported instructions and methods remain explicit fallbacks; they are not transformed into native code. VM control-flow hardening applies only to methods actually emitted through the VM backend. No anti-debugging, anti-emulator, stealth, or analysis-evasion behavior is implemented.

**Production signing is blocked until the signing workflow is replaced.** The project bundles `app/src/main/assets/engine/debug.keystore`, and `ProtectionEngine` uses that shared debug keystore to sign output APKs. A shared debug signing identity is not suitable for production distribution. Replace it with an explicit, user-controlled release-signing workflow and private release credentials before shipping. This task did not change signing behavior or include private signing material in these notes.

## Platform and verification status

The Android module declares `minSdk 24`, `targetSdk 28`, `compileSdk 36`, and Java/Kotlin 17. The available environment had no Android SDK environment variables, `adb`, `sdkmanager`, or `ndk-build`; no Android APK build, device/emulator run, or Android runtime compatibility test is claimed.

The repeatable host verification command, run from the project root, is:

```bash
./host-tests/gradlew -p host-tests clean test
```

The host suite exercises Java security and translation code plus portable C++ VM parity harnesses. Passing it does not substitute for a real Android NDK build, APK signing validation, or device testing.
