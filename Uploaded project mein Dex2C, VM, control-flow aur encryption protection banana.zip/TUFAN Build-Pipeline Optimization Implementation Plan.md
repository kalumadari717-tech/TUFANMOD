# TUFAN Build-Pipeline Optimization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Reduce repeated DEX parsing, tree walks, and per-method smali file I/O while proving that backend decisions and generated APK semantics remain equivalent.

**Architecture:** Build one immutable per-invocation DEX/method index and pass it through selection and wrapper generation. Group smali edits by file so each file is walked/read/written once. Use deterministic operation counters and synthetic multi-DEX/multi-method fixtures rather than fragile wall-clock thresholds. Preserve the existing transformation behavior and encryption randomness; compare decrypted payloads and semantic dispositions, not randomized ciphertext bytes.

**Tech Stack:** Java 17, dexlib2 2.5.2, Gradle Wrapper 8.10.2, JUnit 4.13.2.

**Spec:** `docs/superpowers/specs/2026-10-20-tufan-all-protections-design.md`

## Global Constraints

- Preserve minSdk 24, targetSdk 28, compileSdk 36, Java/Kotlin 17, ABI selection, manifest/app identity, annotation metadata, JNI contracts, and all public method signatures.
- Only selected user target classes are transformed; report unselected scope separately and do not rewrite it.
- The optimization must not change C++/TKS VM/Java fallback choices, output semantics, encryption authentication, or release-gate outcomes.
- No runtime cache or persistent cross-build state; each build gets a fresh immutable index.
- Measure deterministic counts of DEX loads, classes/methods visited, tree walks, file reads, and file writes; do not claim a wall-time percentage without a representative APK baseline.
- Run TDD for each behavior change and verify with `./host-tests/gradlew -p host-tests clean test`; the source archive has no Git metadata.

## Review Focus

- Multi-DEX APKs with duplicate class descriptors or missing target classes produce deterministic indexes and explicit errors rather than silently choosing the wrong DEX.
- Repeated method lookups reuse one parsed DEX entry and preserve exact `MethodInfo.toDexSignature()` matches.
- Several methods in one smali file produce one file walk/read/write while applying the same per-method edits in stable order.
- Randomized AES-GCM nonces differ across builds, so optimization equivalence compares plaintext/decrypted semantics and not ciphertext equality.
- Exceptions or cancellation during a batched rewrite do not leave a partially rewritten smali file; write changes through a temporary file and atomic replace where supported.

---

### Task 1: Add immutable per-build DEX method index

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/dex/ApkMethodIndex.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/dex/DexScanner.java:25-121`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/dex/ApkMethodIndexTest.java`

**Interfaces:**
- `ApkMethodIndex.load(Path apk) -> ApkMethodIndex` loads each root DEX entry once and indexes immutable `MethodInfo` and dexlib2 `Method` references by DEX entry, class descriptor, and full method signature.
- `findMethod(String signature) -> Optional<IndexedMethod>` returns the matching method and source DEX entry; duplicate ambiguous signatures are explicit validation errors.
- `operationCounts() -> IndexOperationCounts` returns deterministic DEX-load, class-visit, and method-visit totals for evidence; it carries no raw paths.
- Existing `DexScanner.scanApk(File)` remains as a compatibility wrapper over the index.

- [ ] **Step 1: Write failing index tests**

Add `loadsEachDexEntryOnce`, `indexesMethodsByFullSignature`, `preservesDexEntryForMultidexMethod`, `rejectsDuplicateAmbiguousSignature`, `reportsMissingSignature`, and `returnsStableSortedClassAndMethodViews`. Build APK fixtures with two generated DEX entries and assert exact operation counts.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkMethodIndexTest'`
Expected: FAIL because scanner exposes lists but has no reusable immutable index or operation counters.

- [ ] **Step 3: Implement one-pass index construction**

Load the APK container once, visit every supported root DEX and class/method once, store immutable maps/lists, and reject duplicate ambiguous signatures. Keep `scanApk` result ordering unchanged.

- [ ] **Step 4: Run focused and full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkMethodIndexTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: load/visit counters are deterministic and scanner compatibility tests pass.

---

### Task 2: Reuse index during backend translation and method selection

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java:87-145,235-270`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java:159-220,250-320`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriterIndexReuseTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/dex/ProtectionEngineIndexReuseTest.java`

**Interfaces:**
- Add a detailed writer overload consuming `ApkMethodIndex`; retain path/list overloads as adapters.
- `NativeWrapperWriter` must not call `DexFileFactory.loadDexFile` once per target method.
- Engine passes the already-scanned index through target matching, DEX extraction, backend translation, and report generation.

- [ ] **Step 1: Write failing reuse/counter tests**

Add `manyMethodsInOneDexUseOneDexLoad`, `mixedBackendsUseTheSameIndexedMethod`, `unselectedClassNeverGetsTranslated`, and `indexReuseDoesNotChangeMethodDisposition`. Assert DEX-load count is one per root entry regardless of method count and all backend decisions match the reference fixture.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterIndexReuseTest' --tests '*ProtectionEngineIndexReuseTest'`
Expected: FAIL because `translateIfAvailable` currently opens/scans DEX entries for each method.

- [ ] **Step 3: Implement indexed lookup**

Use `ApkMethodIndex.findMethod` for backend translation; remove repeated nested DEX parse loops. Thread one index through a build invocation only and discard it after completion/cancellation.

- [ ] **Step 4: Verify output equivalence and full suite**

Compare C++/VM/fallback dispositions, emitted wrapper symbol sets, and decrypted method/string payloads for deterministic synthetic APKs. Run both focused test classes and `./host-tests/gradlew -p host-tests clean test`.
Expected: operation counts improve; semantic outputs remain equivalent.

---

### Task 3: Batch smali edits per source file

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcher.java:28-80,92-159`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliLogStripper.java` (from compatibility-transforms plan)
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliRewriteCoordinator.java`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliBatchRewriteTest.java`

**Interfaces:**
- `SmaliRewriteCoordinator.rewrite(Path smaliRoot, List<MethodInfo> methods, ProtectionFeatures features, byte[] buildKey) -> RewriteSummary` batches only smali body/string edits and recognized log-removal edits, returning `FileRewriteCounts(filesWalked, filesRead, filesWritten, methodsPatched, linesChanged)`.
- DEX-based private-method obfuscation remains a separate transformation from the compatibility-transforms plan and is not forced into smali batching.
- Apply edits in deterministic source order; write a temporary sibling and atomically replace only after all edits for the file succeed.
- On malformed smali, failed envelope sealing, or I/O error, do not publish a partially rewritten file; propagate failure and preserve the original bytes.

- [ ] **Step 1: Write failing batching and atomicity tests**

Add `threeMethodsInOneFileCauseOneReadAndWrite`, `separateFilesAreWrittenOnceEach`, `failedSecondEditLeavesOriginalFileUnchanged`, `batchOrderIsDeterministic`, and `envelopesStillRoundTripWithRandomNonces`. Assert coordinator-local counters, original-file hashes on failure, and semantic decrypted text.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliBatchRewriteTest'`
Expected: FAIL because current patch loop walks, reads, and writes the same smali file once per method.

- [ ] **Step 3: Implement grouped edit plan and atomic write**

Resolve all target methods to source files in one tree walk; parse each file once; apply approved edits against a stable in-memory representation; write to a temp sibling and atomic-move with a safe replace fallback. Preserve metadata skip behavior and transformation reports from the compatibility plan.

- [ ] **Step 4: Run focused transformation tests and full suite**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliBatchRewriteTest' --tests '*SmaliPatcherStringEncryptionTest' --tests '*SmaliLogStripperTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: fewer file operations with equivalent supported rewrites and unchanged unsupported methods.

---

### Task 4: Add reproducible operation-count benchmark fixture

**Files:**
- Create: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/BuildOperationCountTest.java`
- Create: `host-tests/src/test/resources/fixtures/multidex-generated/README.md`
- Modify: `docs/protection-security-notes.md`

**Interfaces:**
- Fixture records deterministic input shape (DEX count, class count, selected method count, smali files) and expected operation-count bounds.
- The benchmark reports operation counts, not a timing threshold; random GCM output is checked by opening envelopes with the test key.

- [ ] **Step 1: Write failing operation-count acceptance test**

Add `indexedBatchPipelineBoundsLoadsWalksReadsAndWrites`; assert exactly one load per root DEX, at most one traversal per indexed rewrite phase, and at most one read/write per modified smali file in the batched coordinator.

- [ ] **Step 2: Run it to verify current repeated-work regression**

Run: `./host-tests/gradlew -p host-tests test --tests '*BuildOperationCountTest'`
Expected: FAIL on repeated DEX parsing or per-method file reads/writes before the optimization tasks land.

- [ ] **Step 3: Add deterministic fixture description and report operation metrics**

Document fixture dimensions and update security notes to distinguish measured operation counts from elapsed-time benchmarks or Android runtime performance.

- [ ] **Step 4: Run full suite**

Run: `./host-tests/gradlew -p host-tests clean test`.
Expected: all count bounds pass and no performance claim exceeds the evidence.

---

## Completion Gate

Optimization is complete only when the full host suite passes, index/file-operation counters meet deterministic bounds, and before/after method dispositions, public descriptors, annotations, manifest identity, decrypted payload semantics, and non-target APK entries match. Do not claim a wall-time or Android runtime improvement without a representative APK and device benchmark.
