# TUFAN Compatibility-Preserving Transformations Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add opt-in log cleanup, narrowly scoped private-method renaming, and a safe existing-Application crash hook without changing Android annotation, JNI, reflection, manifest, package, component, or public API behavior.

**Architecture:** Keep each optional transform in a separate planner/rewriter with typed applied/skipped/failed evidence. Run compatibility analysis before modifying smali/DEX. Unsupported or ambiguous inputs stay byte-for-byte unchanged; generic annotation encryption and manifest/package/component identity mangling are explicitly reported unsupported, not simulated or labeled applied. Crash-handler status remains unverified until Android runtime tests pass.

**Tech Stack:** Java 17, dexlib2/smali 2.5.2, Gradle Wrapper 8.10.2, JUnit 4.13.2, Android instrumentation tests from the release-integrity plan.

**Spec:** `docs/superpowers/specs/2026-10-20-tufan-all-protections-design.md`

## Global Constraints

- Compatibility is mandatory; preserve Android-visible annotations/defaults, manifest/app ID, component names/authorities, JNI declarations, reflection-visible names, and public descriptors.
- Generic annotation encryption and manifest/package/component mangling are unsupported under this constraint; return `SKIPPED_UNSUPPORTED_COMPATIBILITY` and never `VERIFIED_APPLIED`.
- All transforms are opt-in and default off. A safe skip is reported as partial protection; never silently treat a skip as application.
- Log removal is limited to direct recognized `android.util.Log.v/d/i` calls with unused return values and provably safe instruction context.
- Private renaming is restricted to explicitly allowlisted private methods with complete DEX-wide reference closure; no class, field, package, component, authority, JNI, or reflection-sensitive renames.
- Crash handling may touch only an existing safely instrumentable Application class; do not add, rename, or replace manifest components/Application classes. Preserve and delegate to the prior uncaught handler.
- Run each behavior change RED → GREEN using `./host-tests/gradlew -p host-tests test`; supplied source archive has no Git metadata.

## Review Focus

- Annotation-bearing methods and annotation interfaces/defaults remain unchanged when the rewriter cannot prove exact metadata preservation.
- Log calls with `move-result`, `/range`, try/catch membership, labels/branches, or unknown owner are skipped unless a dedicated test proves equivalence.
- Private method references across multiple DEX entries are rewritten consistently; reflective strings, method handles, external references, or uncertain closure cause a safe skip.
- Crash-hook injection does not alter binary manifest bytes, install a new Application class, clear a crash, or lose an existing uncaught handler.
- An enabled feature with no eligible candidates is reported `NOT_APPLICABLE`; an eligible but unsafe candidate is `SKIPPED_UNSUPPORTED_COMPATIBILITY`; neither is mislabeled applied.

---

### Task 1: Add typed opt-in transformation configuration

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionFeatures.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/TransformResult.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionRequest.java` (from the hybrid-verification plan)
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionReport.java` (from the hybrid-verification plan)
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/model/ProtectionFeaturesTest.java`

**Interfaces:**
- `ProtectionFeatures(boolean stripDebugLogs, boolean installCrashHandler, boolean obfuscatePrivateMethods, Set<Feature> requiredFeatures)`; all booleans default false.
- `TransformResult` is an immutable per-feature result containing status, changed-file count, applied/skipped candidate counts, and stable reason codes; it never stores payloads or rename mappings.
- Do not define annotation-encryption or manifest-mangling switches; those are unsupported by design.
- Unsupported capabilities may appear in reports as skipped, but cannot be enabled through `ProtectionFeatures` or produce transformed output.
- Feature results use `FeatureEvidence.Status`; optional safe skips yield `PROTECTION_PARTIAL`, while a feature explicitly marked required cannot silently skip.

- [ ] **Step 1: Write failing option/default/report tests**

Add `allOptionalTransformsDefaultOff`, `unsupportedTransformsCannotBeEnabled`, `optionalSafeSkipProducesPartialStatus`, `requiredSafeSkipFailsBuild`, and `noEligibleCandidateIsNotApplied`. Assert immutable set access and stable reason codes.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ProtectionFeaturesTest'`
Expected: FAIL because a typed optional-feature configuration does not exist.

- [ ] **Step 3: Implement immutable option and report-state types**

Add default-off feature configuration and extend the report model from the core plan. Reject unknown required feature IDs; do not expose annotation encryption or manifest mangling as toggles.

- [ ] **Step 4: Run focused and full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*ProtectionFeaturesTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: flags alone never generate applied evidence; all tests pass.

---

### Task 2: Implement narrow, semantics-preserving log removal

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliLogStripper.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java` (request/config integration after the core report API exists)
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliLogStripperTest.java`

**Interfaces:**
- `SmaliLogStripper.strip(Path smaliRoot, Set<String> selectedClassDescriptors) -> TransformResult`.
- `TransformResult` reports removed and skipped call counts by stable reason code; a skip never changes the source.
- Recognize only direct `invoke-static` calls to `android.util.Log.v/d/i` whose int result has no immediate `move-result`; preserve `w/e/wtf`, `/range`, unknown owners, malformed blocks, and protected-tool diagnostics.

- [ ] **Step 1: Write failing smali transformation tests**

Add `removesDebugInfoVerboseCallsWithUnusedResult`, `preservesCallsWithMoveResult`, `preservesWarningErrorAndWtf`, `preservesRangeAndTryCatchCalls`, `preservesUnknownOwners`, and `countsRemovedAndSkipped`. Assert unchanged lines for every skipped case and removal only of the recognized invoke instruction.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliLogStripperTest'`
Expected: FAIL because no log-strip transformation exists.

- [ ] **Step 3: Implement conservative parser and result counts**

Use a line-aware smali parser that tracks method boundaries, labels, try/catch regions, and immediate result instructions. On malformed/ambiguous input, preserve the entire method and record a skip; do not use broad regex deletion.

- [ ] **Step 4: Run focused/full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliLogStripperTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: exact supported invokes are removed; all uncertain or unsupported forms remain unchanged.

---

### Task 3: Rename only allowlisted private methods with closed references

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/PrivateMethodObfuscator.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/MethodKey.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java` (configuration/evidence integration)
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/PrivateMethodObfuscatorTest.java`

**Interfaces:**
- `MethodKey(classDescriptor, name, methodDescriptor)` identifies one input method.
- `PrivateMethodObfuscator.plan(List<DexFile> dexFiles, Set<MethodKey> allowlist, byte[] buildSeed) -> RenamePlan`; `apply(RenamePlan, List<Path> dexEntries) -> TransformResult`.
- Names are generated per build from a cryptographic seed; mappings live only in memory and are excluded from default reports/logs.
- Rename only private methods whose declaration, all same-app invoke/reference sites, and DEX IDs can be rewritten. Skip if reflection-like string references, method handles/call sites, external references, annotations, or incomplete multidex closure are detected.

- [ ] **Step 1: Write failing multidex and skip-safety tests**

Add `renamesAllowlistedPrivateMethodAndAllInternalCalls`, `preservesPublicAndProtectedMethodNames`, `preservesClassPackageAndManifestIdentity`, `skipsPossibleReflectionStringReference`, `skipsExternalOrIncompleteReferenceClosure`, `keepsAnnotationBearingCandidateUnchanged`, and `doesNotExposeMappingInReport`. Use synthetic DEX fixtures with a private invoke-direct caller split across DEX entries.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*PrivateMethodObfuscatorTest'`
Expected: FAIL because no private-method rewrite/closure analysis exists.

- [ ] **Step 3: Implement a plan/apply two-phase rewrite**

First build the whole-APK reference index and reject any unsafe candidate; only then produce a collision-free mapping and rewrite definitions/references across the complete selected DEX set. If any operation fails, discard the whole rename plan and leave affected methods untouched; never partially rewrite a class graph.

- [ ] **Step 4: Verify reopened DEX and exact identity invariants**

Reopen all transformed DEX with dexlib2 and assert no stale old method references remain for applied methods, all skipped declarations/references are unchanged, and manifest/component/public identity snapshots match.

- [ ] **Step 5: Run focused and full host suites**

Run: `./host-tests/gradlew -p host-tests test --tests '*PrivateMethodObfuscatorTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: only complete safe mappings are emitted; full suite passes.

---

### Task 4: Add an existing-Application-only delegating crash hook

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/CrashHookInjector.java`
- Create: `app/src/main/assets/engine/runtime/TufanCrashHandler.smali`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ApplicationSnapshot.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java` (opt-in gate and evidence)
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/CrashHookInjectorTest.java`
- Test: `app/src/androidTest/java/com/dex2cpro/TUFAN/engine/CrashHookRuntimeTest.kt` (from release-integrity runtime fixture)

**Interfaces:**
- `ApplicationSnapshot` is derived from the decoded original manifest and contains only explicit Application class descriptor, source declaration count, and a digest of the original manifest bytes.
- `CrashHookInjector.inject(Path smaliRoot, ApplicationSnapshot existingApplication) -> TransformResult`.
- Accept only a unique existing manifest-declared Application class with an analyzable lifecycle insertion point. The injector cannot change manifest bytes or class name and must preserve/delegate to the previous default uncaught handler exactly once.
- When absent/ambiguous/unsafe or unverified at Android runtime, return `SKIPPED_UNSUPPORTED_COMPATIBILITY` or `UNVERIFIED`; do not claim applied.

- [ ] **Step 1: Write failing eligibility and source-preservation tests**

Add `defaultApplicationIsUnsupported`, `missingOrDuplicateApplicationClassIsUnsupported`, `customApplicationHookPreservesManifestBytes`, `existingHandlerIsSavedAndDelegatedOnce`, `diagnosticFailureCannotSwallowOriginalCrash`, and `unsafeLifecycleDoesNotModifySmali`. Use temporary manifests and smali files.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*CrashHookInjectorTest'`
Expected: FAIL because no target-app crash hook eligibility or injector exists.

- [ ] **Step 3: Implement only the proved existing-Application path**

Inject the runtime helper only after complete eligibility validation. Do not create a new Application class, alter manifest attributes, use network/UI work, swallow the original failure, or change process termination. In every uncertain case, emit a skip result with the original files unchanged.

- [ ] **Step 4: Add Android runtime assertions and keep unsupported status until executed**

The instrumentation test must exercise a synthetic uncaught exception on a test thread, prove prior handler is invoked once, and prove normal process crash behavior is not swallowed. If no device runner is configured, record `UNVERIFIED`; do not mark the feature applied or release-ready.

- [ ] **Step 5: Run available checks**

Run: `./host-tests/gradlew -p host-tests clean test`. Run the Android instrumentation test only with a configured runner using the release-integrity plan's API/ABI matrix.
Expected: host tests pass; feature remains unverified until Android evidence exists.

---

### Task 5: Report unsupported compatibility-breaking requests honestly

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ProtectionVerifier.java` (from the hybrid-verification plan)
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionReport.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/UnsupportedProtectionStatusTest.java`

**Interfaces:**
- The report includes stable features `ANNOTATION_ENCRYPTION` and `IDENTITY_MANGLING` only to emit `SKIPPED_UNSUPPORTED_COMPATIBILITY`; there is no implementation toggle or ciphertext/mangling output.
- Aggregate outcome remains partial, not complete, when the user requests either unsupported transformation.

- [ ] **Step 1: Write failing status tests**

Add `annotationEncryptionCapabilityIsReportedUnsupported`, `identityManglingCapabilityIsReportedUnsupported`, `unsupportedNeverHasAppliedEvidence`, and `compatibilitySkipMakesOutcomePartial`. Verify manifest/annotation bytes are untouched in the associated fixture; neither capability is user-enableable.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*UnsupportedProtectionStatusTest'`
Expected: FAIL because no explicit unsupported-feature reporting exists.

- [ ] **Step 3: Implement typed unsupported evidence**

Add the stable status/reason codes and ensure requests cannot activate an unsafe transform. Preserve the source artifact and link feature status into the immutable report.

- [ ] **Step 4: Run focused/full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*UnsupportedProtectionStatusTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: requests are explicit, no false applied status is possible, and the host suite passes.

---

## Completion Gate

This track is complete only when every optional transform is off by default, every applied transform has artifact evidence and compatibility tests, every unsafe/unknown input is unchanged and reported as skipped, and annotation/app/component identity invariants pass. A host crash-hook source test cannot establish Android runtime compatibility; that feature remains `UNVERIFIED` until the release-integrity Android runner passes.
