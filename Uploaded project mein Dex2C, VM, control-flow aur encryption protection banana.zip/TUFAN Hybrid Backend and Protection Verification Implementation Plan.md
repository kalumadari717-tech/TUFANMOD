# TUFAN Hybrid Backend and Protection Verification Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make per-method C++/TKS VM/Java-fallback selection, JNI registration, and protection evidence correct, explicit, immutable, and testable.

**Architecture:** Keep `NativeWrapperWriter` as the backend emitter, but return an immutable generation result instead of relying on process-global last-build state. Add a typed report model and pure policy/verifier seams so host tests can prove method dispositions and artifact evidence without Android framework dependencies. The legacy callback remains available; method-local compile/validation failure retries the next backend and then preserves Java fallback.

**Tech Stack:** Java 17, dexlib2 2.5.2, Gradle Wrapper 8.10.2, JUnit 4.13.2, existing portable C++17 VM parity harness.

**Spec:** `docs/superpowers/specs/2026-10-20-tufan-all-protections-design.md`

## Global Constraints

- Preserve minSdk 24, targetSdk 28, compileSdk 36, Java/Kotlin 17, and existing user-selected ABIs.
- Candidate methods are only concrete methods in user-selected target classes; report out-of-scope counts separately and never rewrite those classes.
- Use `CPP`, `TKS_VM`, `JAVA_FALLBACK`, and `NOT_APPLICABLE` backend dispositions; speculative attempts and counters are not evidence.
- Preserve callable Java bodies on every fallback; strip a renamed original only when its exact original signature is verified fully native.
- Preserve annotations, JNI descriptors, reflection-sensitive names, Android component identity, and app ID; generic annotation encryption and component/manifest mangling remain unsupported.
- Never clear a required JNI exception and continue; a required registration failure must make `JNI_OnLoad` return `JNI_ERR`.
- Do not claim native coverage, key secrecy, Android runtime success, or release success without the evidence required by the spec.
- Run each task RED → GREEN using `./host-tests/gradlew -p host-tests test`; this source archive has no Git metadata, so do not invent commit claims.

## Review Focus

- Mixed selected methods where one emits C++, one TKS VM, and one fails both: the last method must retain a callable original body and the counts must partition all candidates.
- A fully-native signature and a fallback with similar `d2c$orig$` names: stripping must remove only the exact fully-native original.
- Annotated method/parameter/type metadata on a candidate: preserve it on the original callable declaration or leave the entire method unchanged.
- JNI helper/class lookup and `RegisterNatives` failure: pending exceptions remain visible and required registration failure cannot return successful `JNI_OnLoad`.
- Two concurrent or sequential writer invocations: no stale backend report may leak across builds or become published before the generated file exists.
- Exact-class and explicit package-wildcard selectors include only intended classes; malformed or empty selectors fail before any APK mutation.

---

### Task 1: Strip only exact fully-native original bodies and preserve metadata

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcher.java:52-80,92-159`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcherBodyStripTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcherAnnotationCompatibilityTest.java`

**Interfaces:**
- Keep `stripOriginalBodies(Path decompiledDir, Set<String> fullyNativeSignatures) -> int`.
- `fullyNativeSignatures` contains original `MethodInfo.toDexSignature()` values only; never accept prefix or substring matches.
- An unsafe metadata case returns “not transformed” and leaves the original method and metadata unchanged.
- Before moving a method body or annotation block, `patchMethod` detects method/parameter/type-use annotations and conservatively skips that method; body stripping also refuses to delete a metadata-bearing renamed method.

- [x] **Step 1: Write the failing body-strip tests**

Add `stripRemovesOnlyExactFullyNativeSignature`, `retainsFallbackAndUnrelatedRenamedMethods`, and `emptyNativeSetChangesNothing`. Build a temporary smali tree containing at least two renamed originals in one class; provide only one matching original signature and assert only its corresponding body is deleted.

- [x] **Step 2: Run the tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliPatcherBodyStripTest'`
Expected: FAIL because the current implementation strips all methods containing `d2c$orig` whenever the set is non-empty.

- [x] **Step 3: Implement exact signature matching**

Parse each `.method` declaration into class, method name, and descriptor; map the renamed body to its original `MethodInfo.toDexSignature()` using the same rename helper used by patching. Delete only when that exact signature belongs to the fully-native set. Leave malformed/unparseable declarations untouched.

- [x] **Step 4: Add and run annotation-preservation RED/GREEN tests**

Add `annotatedCandidateRemainsEntirelyUnchanged` for runtime-visible method and parameter annotation fixtures, and `annotationDefaultInterfaceRemainsUnchanged` for an annotation interface. Exercise the real `SmaliPatcher.patch` path; first observe that it relocates method annotations onto `d2c$orig$...`, then add the conservative pre-relocation skip and assert byte-for-byte smali equality and an empty patched-method result.

- [x] **Step 5: Run focused and full host suites**

Run: `./host-tests/gradlew -p host-tests test --tests '*SmaliPatcherBodyStripTest' --tests '*SmaliPatcherAnnotationCompatibilityTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: exact-strip and metadata tests pass; all existing tests pass.

---

### Task 2: Return per-method backend evidence without process-global mutable state

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/Backend.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/MethodDisposition.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/GenerationResult.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java:34-145`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java:306-324`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriterEvidenceTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/model/GenerationResultTest.java`
- Modify: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/ProtectionAccountingTest.java`

**Interfaces:**
- `Backend`: `CPP`, `TKS_VM`, `JAVA_FALLBACK`, `NOT_APPLICABLE`.
- `MethodDisposition`: immutable `signature`, `backend`, `reasonCode`, `emitted`, and `verified` values; defensively validate non-null stable identifiers.
- Add `NativeWrapperWriter.writeDetailed(Path cppFile, List<MethodInfo> methods, List<File> dexFiles, byte[] runtimeKey, byte[] sealedManifest, String expectedBuildId, String expectedModuleName) -> GenerationResult`; retain existing `write(...)` overloads as compatibility wrappers.
- `GenerationResult` exposes immutable ordered `dispositions()`, derived `fullyNativeSignatures()`, and derived `backendCounts()` returning `GenerationResult.BackendCounts(cppMethods, vmMethods, fallbackMethods)`; construct/publish it only after the generated C++ file is written successfully.
- A disposition is generation-verified only when its wrapper/trampoline was emitted and the output file write completed; this is not NDK compilation or Android runtime verification. `reasonCode` distinguishes successful CPP/VM generation from missing DEX, missing method, unsupported method, and missing VM key.
- `ProtectionEngine` consumes the returned result directly for counts and exact body-strip signatures. Remove process-global `lastBackendSnapshot` and its accessors after migrating production and host-test callers; there must be no mutable last-build source of truth.

- [x] **Step 1: Write failing generation-result tests**

Add `reportsCppVmAndFallbackForMixedMethods`, `reportsDuplicateSignatureOnce`, `rejectsDistinctSignaturesThatCollideOnJniSymbol`, `doesNotReusePreviousInvocationResults`, and `doesNotPublishResultWhenCppWriteFails`. Assert every generated JNI wrapper symbol occurs once, counts are derived from emitted/verified final dispositions and sum to the unique candidate count, and fully-native signatures exclude fallback. `GenerationResultTest` also covers immutable snapshots, validated dispositions, and ignoring unverified attempts.

- [x] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterEvidenceTest'`
Expected: FAIL because writer output is currently void and backend evidence exists only in static `lastBackendSnapshot`.

- [x] **Step 3: Implement immutable result-bearing generation**

Introduce the enum/records in the model package and a detailed writer entry point. Store decisions locally during generation, write the C++ file, then construct and return the immutable result. Update `ProtectionEngine` and `ProtectionAccountingTest` to consume that result; remove global last-build state/accessors. Preserve existing `write(...)` overloads as wrappers that delegate and discard the returned result.

- [x] **Step 4: Verify focused and full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterEvidenceTest' --tests '*ProtectionAccountingTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: no cross-build stale counts; all existing accounting and native-generation tests pass.

---

### Task 3: Fail closed on required JNI helper and method registration failure

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java:744-804`
- Modify: `app/src/main/assets/engine/jni/nc/Dex2C.cpp:280-297`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriterRuntimeFailureTest.java`

**Interfaces:**
- Generated `dynamic_register_compile_methods(JNIEnv*)` returns `nullptr` only if every required registration succeeds; otherwise returns a stable error string and preserves any pending JNI exception.
- `JNI_OnLoad` returns `JNI_ERR` on a non-null registration failure or pending required exception; it never reports native loading success with required helpers unregistered.

- [x] **Step 1: Add failing generated-source assertions**

Add tests `requiredHelperRegistrationFailureIsReturned`, `targetClassLookupFailureIsReturned`, `noRequiredRegistrationExceptionIsCleared`, `jniOnLoadRejectsRegistrationFailure`, and `methodRuntimeHelperIsOptionalWithoutBuildKey`. Assert required `FindClass`/`RegisterNatives` failures are observable, pending exceptions are preserved, optional TKS runtime registration is omitted without a build key, and the JNI load result is `JNI_ERR`.

- [x] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterRuntimeFailureTest'`
Expected: FAIL because generated code clears exceptions and `Dex2C.cpp` only logs a warning before returning `JNI_VERSION_1_6`.

- [x] **Step 3: Implement required-registration propagation**

Generate immediate error returns after required lookup/registration failure without clearing pending exceptions. Update `JNI_OnLoad` to return `JNI_ERR` when the generated registration function fails; keep optional registration paths explicitly classified and tested rather than silently swallowed.

- [x] **Step 4: Run source assertions and full suite**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterRuntimeFailureTest' --tests '*NativeWrapperWriterStringTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: focused JNI-source tests and the complete host suite pass.

---

### Task 4: Define immutable protection report and evidence verifier

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionReport.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/FeatureEvidence.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/BackendCapabilities.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ProtectionVerifier.java`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/ProtectionVerifierTest.java`

**Interfaces:**
- `ProtectionReport.BuildStatus`: `RELEASE_SUCCESS`, `DEV_SUCCESS`, `PROTECTION_PARTIAL`, `FAILED`, `UNVERIFIED`.
- `FeatureEvidence.Status`: `VERIFIED_APPLIED`, `SAFE_FALLBACK`, `NOT_APPLICABLE`, `SKIPPED_UNSUPPORTED_COMPATIBILITY`, `FAILED`, `UNVERIFIED`.
- `BackendCapabilities` is an immutable capability table listing only DEX/VM opcode families covered by named compiler, malformed-input, and parity fixtures; the table is build metadata, not inferred from an enabled flag.
- `ProtectionReport` carries immutable per-method dispositions, per-feature evidence, aggregate scope/backend counts, and build status; defensive copies prevent caller mutation.
- Duplicate `GenerationResult` signatures are rejected at value-object construction; `ProtectionVerifier.verifyGeneration(GenerationResult, Set<String> expectedCandidates) -> VerificationResult` rejects missing/unexpected methods, count mismatches, backend output without emitted evidence, and fallback falsely marked native.

- [x] **Step 1: Write failing verifier/report tests**

Add `countsRequireExactCandidatePartition`, `enabledFlagCannotCreateVerifiedApplied`, `fallbackCannotCountAsNative`, `duplicateOrMissingMethodFailsVerification`, `unverifiedBackendOutputIsRejected`, `reportCollectionsAreImmutableAndCountsAreDerived`, `noEligibleFeatureIsNotApplicable`, `compatibilitySkipIsNeverReportedAsApplied`, and `capabilityTableContainsOnlyTestedFamilies`.

- [x] **Step 2: Run the tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ProtectionVerifierTest'`
Expected: FAIL because typed report/evidence types and verifier do not exist.

- [x] **Step 3: Implement report and verifier types**

Create only the immutable data types and checks pinned by the tests. Do not serialize full method inventories, keys, plaintext, or raw filesystem paths. Derive all counts from verified dispositions.

- [x] **Step 4: Run focused and full tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*ProtectionVerifierTest' --tests '*NativeWrapperWriterEvidenceTest'`, then `./host-tests/gradlew -p host-tests clean test`.
Expected: evidence cannot be created from a request flag alone; full host suite passes.

---

### Task 5: Integrate per-method policy and additive report callback

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionRequest.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/TargetSelector.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/BackendSelectionPolicy.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionCallbacks.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/BackendCapabilities.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java:48-101,159-212,260-320`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/BackendSelectionPolicyTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/TargetSelectorTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/ProtectionEngineReportCompatibilityTest.java`

**Interfaces:**
- `BackendSelectionPolicy.select(MethodInfo, BackendCapabilities, boolean forceNative, BackendAttempt<T> cpp, BackendAttempt<T> vm) -> Selection<T>` invokes CPP first, invokes VM only after CPP declines, and selects only non-null validated outputs. The selection carries the generated value and can create its `MethodDisposition`. `BackendCapabilities` gates only backends with named test evidence. If neither succeeds, safe mode records Java fallback; force-native throws before the wrapper file is written.
- `TargetSelector.parse(List<String>) -> TargetSelector` accepts exact DEX class descriptors, exact dotted class names (one-segment default-package names or fully qualified names with at least three segments), and a trailing `.*` for an explicit package subtree. A two-segment package-shaped value must use `.*` or an exact DEX descriptor. Reject empty values, malformed descriptors, and embedded wildcards. `matches(String classDescriptor) -> boolean` uses exact descriptor boundaries, not substring matching.
- `ProtectionRequest` is immutable and carries parsed selectors plus all existing run options; the legacy `selectedClasses` overload adapts only exact class names and never interprets `.*` as a package selector.
- `ProtectionEngine.LogCallback` extends the host-testable `ProtectionCallbacks` contract, retains `onComplete(boolean, String)`, and inherits the default no-op `onProtectionReport(ProtectionReport)` method; existing implementers need no new override.
- Add a request-based `run(ProtectionRequest)` overload; keep the legacy `run(...)` signature as an adapter with its old argument meanings.

- [x] **Step 1: Write failing selection and callback-compatibility tests**

-Add `matchesExactDottedAndDescriptorClass`, `matchesSingleSegmentClassNameStartingWithL`, `matchesExplicitPackageSubtreeWithoutPrefixCollision`, `rejectsBareAmbiguousPackageAndMalformedSelector`, `cppWinsOnlyWhenValidated`, `vmIsTriedAfterCppDeclines`, `fallbackIsRecordedWhenBothDecline`, `forceNativeRejectsFallback`, `emptyOrAmbiguousSelectorFailsBeforePatch`, and `legacyCallbackStillReceivesCompletion`. Use generated `MethodInfo` fixtures and real pure selector/policy objects; do not mock Android framework behavior. Backend-attempt tests assert call ordering and that an unvalidated or empty output cannot be counted as native.

- [x] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*TargetSelectorTest' --tests '*BackendSelectionPolicyTest' --tests '*ProtectionEngineReportCompatibilityTest'`
Expected: FAIL because selection is embedded in engine flow and no typed request/report callback exists.

- [x] **Step 3: Implement the pure selection/request boundary**

Move concrete method-local choice into `BackendSelectionPolicy` by passing its real compiler attempts from `NativeWrapperWriter`; parse selectors before any transformation, connect `writeDetailed` results to `ProtectionVerifier`, and add the additive report callback. `forceNative=true` fails before APK export if any selected concrete method remains fallback; `forceNative=false` records partial safe fallback. Do not report unselected methods as transformed.

- [x] **Step 4: Run focused/full suites and inspect API compatibility**

Run focused classes above, then `./host-tests/gradlew -p host-tests clean test`. Confirm an existing callback implementation needs no new override and old `run(...)` delegates to the request API.
Expected: all policy/report tests and the full host suite pass.

---

### Task 6: Validate Dex2C result typing and differential control-flow fixtures

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/DexToCppTranslator.java:78-110,412-429`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/DexCppResultAndSwitchValidationTest.java`
- Modify: `docs/protection-security-notes.md`

**Interfaces:**
- `canTranslateMethod(Method) -> boolean` must reject a `move-result*` opcode unless it exactly matches the immediately preceding invoke/filled-array result descriptor; a void producer cannot be followed by a move-result.
- Valid constructor allocation/invoke pairs and int, wide, object, and void return signatures remain supported only when generated JNI/C++ wrapper types match their DEX descriptors; malformed/unmatched constructor cases decline to fallback.
- No opcode family is newly accepted in this task without an executable C++ or reference-parity test.

- [ ] **Step 1: Write failing malformed-result and semantic fixtures**

Add `rejectsMoveResultKindMismatchForInvoke`, `rejectsMoveResultAfterVoidInvoke`, `validConstructorPairPreservesObjectLifecycle`, `unmatchedConstructorReceiverDeclinesToFallback`, `preservesPrimitiveWideAndObjectReturnShapes`, `packedSwitchCasesMatchReference`, and `sparseSwitchDefaultMatchesReference`. Use immutable synthetic DEX methods; execute supported branch/switch output through the existing native C++ harness and assert invalid result/constructor forms are declined for fallback.

- [ ] **Step 2: Run focused tests to verify the known validation gap**

Run: `./host-tests/gradlew -p host-tests test --tests '*DexCppResultAndSwitchValidationTest'`
Expected: malformed `move-result` cases FAIL because the current validator accepts any immediately preceding `INVOKE_*` without comparing the expected move-result opcode.

- [ ] **Step 3: Implement exact result-producer validation**

Require `expectedMoveResult(previousInstruction)` to equal the current opcode; reject void producers and mismatched primitive/object/wide forms. Validate supported constructor pairs before emission, preserving safe fallback for unmatched or unsupported shapes. Do not broaden the opcode set in this fix.

- [ ] **Step 4: Run focused C++ parity, document capability limits, and run the full suite**

Run: `./host-tests/gradlew -p host-tests test --tests '*DexCppResultAndSwitchValidationTest' --tests '*DexGeneratedCppExecutionTest' --tests '*DexBranchValidationTest'`, then `./host-tests/gradlew -p host-tests clean test`. Update security notes with only the tested support/decline boundary and existing control-flow limitations.
Expected: malformed result forms fail closed, supported switch/return fixtures preserve semantics, and all existing tests pass.

---

## Completion Gate

The core track is complete only when Tasks 1–6 pass the full host suite, every selected concrete candidate has exactly one final disposition, every fallback body remains callable, no required JNI exception is cleared, and no host-only result is described as Android runtime or release verification. Android install/launch acceptance remains owned by the release-integrity plan and requires a configured Android runner.
