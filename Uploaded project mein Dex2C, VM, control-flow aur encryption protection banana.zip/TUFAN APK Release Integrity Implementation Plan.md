# TUFAN APK Release Integrity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ensure APK inputs, rebuilt outputs, signing, and release status are cryptographically and structurally verified, with no unsigned or untested artifact reported as release-success.

**Architecture:** Add a pure ZIP/APK structure validator and before/after invariant verifier, use the existing `apksig:8.7.3` dependency with transient caller-supplied signer credentials, and centralize final status in an explicit gate. Keep an explicitly requested development artifact separate from release output. Android install/runtime smoke checks are an independent mandatory release gate; missing device capability yields `UNVERIFIED` and blocks release success.

**Tech Stack:** Java 17, Android `apksig:8.7.3`, dexlib2 2.5.2, JUnit 4.13.2, Gradle Wrapper 8.10.2.

**Spec:** `docs/superpowers/specs/2026-10-20-tufan-all-protections-design.md`

## Global Constraints

- Preserve the app ID, manifest bytes/semantics, components, authorities, permissions, non-target ZIP payloads, and original update-certificate identity.
- Support one standalone APK with conventional root `classes*.dex` only; reject split/APKS bundles, unsafe ZIP paths, duplicate entries, and malformed inputs.
- A release request requires an explicit per-build signer whose certificate is intended for the original app identity; never use a bundled/shared debug key.
- Never persist signer passwords or private-key material into the source ZIP, report, or normal logs.
- `signApk=false` is explicitly unsigned development output only; it cannot be labeled release-success.
- Rebuilt APK must pass structure and signature verification before export; requested release signing failure or missing verifier/runtime target blocks release success.
- Android runtime verification is mandatory for release claims. Host tests are not a substitute; absent runner means `UNVERIFIED`/blocked.
- Per-task changes use TDD; run `./host-tests/gradlew -p host-tests clean test`. Supplied source archive has no Git metadata, so do not claim commits.

## Review Focus

- Duplicate ZIP entries, path traversal names, split APKs, missing manifest, malformed DEX, and secondary DEX names that are not conventional root `classes*.dex` are rejected before extraction or rewriting.
- ZIP rebuilding preserves all non-target entry bytes and the original manifest exactly while replacing only requested DEX and selected native library entries.
- Signing succeeds only with the caller-provided private key/certificate, and a signature made by a different certificate or tampered output fails verification.
- Failed signing, failed container verification, absent credentials, or unavailable runtime runner never falls through to unsigned export with a success callback.
- Development output is explicitly labeled and separated from release; user cancellation and output-copy failure do not leave stale successful artifacts.

---

### Task 1: Validate APK ZIP input before extraction

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/ApkInputValidator.java`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/ApkInputValidatorTest.java`

**Interfaces:**
- `ApkInputValidator.validate(Path apk) -> ApkInputSnapshot`.
- `ApkInputSnapshot` contains immutable sorted root DEX entry names, SHA-256 hashes for entry names/payloads as needed, manifest payload hash, and byte length; never stores full input payloads.
- Reject split/APKS/unsupported input, duplicate entry names, absolute/traversal/backslash paths, missing or empty `AndroidManifest.xml`, missing root `classes.dex`, invalid `classes*.dex` payloads, and unsupported DEX paths.

- [ ] **Step 1: Write failing input-validation tests**

Add `acceptsValidStandaloneMultiDexApk`, `rejectsDuplicateZipNames`, `rejectsTraversalAndAbsoluteNames`, `rejectsSplitApksAndApksBundle`, `rejectsMissingManifest`, `rejectsMissingRootClassesDex`, and `rejectsMalformedDexBytes`. Generate deterministic temporary ZIP fixtures; for duplicate names, use a fixed byte fixture because `ZipOutputStream` rejects duplicates by default.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkInputValidatorTest'`
Expected: FAIL because no bounded APK ZIP validator exists.

- [ ] **Step 3: Implement validation before extraction**

Read ZIP central-directory entries without extracting files. Normalize and reject unsafe names, enforce uniqueness, parse each root DEX with dexlib2, and return a deterministic immutable snapshot. Reject unsupported APK layouts rather than silently skipping entries.

- [ ] **Step 4: Run focused tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkInputValidatorTest'`.
Expected: all valid/invalid fixture cases pass, with invalid cases raising a typed validation exception before output creation.

---

### Task 2: Verify rebuilt APK invariants and entry preservation

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/ApkIntegrityVerifier.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/RawApkRebuilder.java:27-113`
- Modify: `host-tests/build.gradle`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/ApkIntegrityVerifierTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/RawApkRebuilderTest.java`

**Interfaces:**
- `ApkIntegrityVerifier.verify(Path input, Path output, ApkInputSnapshot before, Set<String> replacedDexEntries, Set<String> replacedLibraryEntries) -> ArtifactVerification`.
- Compare exact manifest payload hash; compare SHA-256 of every non-target entry; require each intended DEX replacement exactly once; parse all output DEX; reject duplicate names, unsafe names, missing required entries, and unexpected deletions.
- APK signatures are excluded from byte-preservation comparisons because rebuild invalidates old signatures; they are checked by Task 3.

- [ ] **Step 1: Write failing preservation/invariant tests**

Add `preservesManifestAndNonTargetPayloads`, `rejectsDuplicateOutputNames`, `rejectsUnexpectedEntryLoss`, `requiresEachReplacedDexExactlyOnce`, and `reopensEveryOutputDex`. Exercise the real `RawApkRebuilder` with synthetic source ZIPs and small generated DEX fixtures.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkIntegrityVerifierTest' --tests '*RawApkRebuilderTest'`
Expected: FAIL because current container check does not compare source/output invariants and the rebuilder does not reject all malformed ZIP states.

- [ ] **Step 3: Implement deterministic rebuild verification**

Implement streaming hashes and exact entry-set comparisons. Ensure `RawApkRebuilder` output is reopened and validated before signing; do not alter the manifest. Keep APK signature artifacts out of unsigned-source invariants.

- [ ] **Step 4: Run focused and full host tests**

Run both focused classes, then `./host-tests/gradlew -p host-tests clean test`.
Expected: rebuilt output validates only when required entries and non-target payloads match.

---

### Task 3: Replace bundled debug signing with explicit per-build signer

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ApkSigningConfig.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ApkSigningService.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/SigningResult.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/SignatureVerification.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java:1139-1265`
- Modify: `host-tests/build.gradle`
- Create: `host-tests/src/test/resources/test-signer/test-cert.pem` (test-only; never ship in app assets)
- Create: `host-tests/src/test/resources/test-signer/test-private-key.pem` (test-only; never ship in app assets)
- Remove: `app/src/main/assets/engine/debug.keystore`
- Remove: `app/src/main/assets/engine/uber-apk-signer.jar`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/ApkSigningServiceTest.java`

**Interfaces:**
- `ApkSigningConfig` is a transient immutable holder for `PrivateKey`, matching `X509Certificate`, and explicit enabled signature schemes; it has no password fields and redacts `toString()`.
- `ApkSigningService.sign(Path apk, ApkSigningConfig config) -> SigningResult` uses `apksig:8.7.3`; `verifyInputIdentity(Path originalApk, ApkSigningConfig expected) -> SignatureVerification` and `verify(Path apk, ApkSigningConfig expected) -> SignatureVerification` check the original update identity, cryptographic validity, configured signer identity, and required schemes.
- Signing never falls back to bundled `debug.keystore` or `uber-apk-signer.jar`.

- [ ] **Step 1: Write failing signer tests**

Add `rejectsMissingSigner`, `signsAndVerifiesWithSuppliedCertificate`, `rejectsSignerNotMatchingOriginalApk`, `rejectsUnexpectedCertificate`, `rejectsTamperedSignedApk`, `reportsMissingRequiredScheme`, and `neverSerializesPrivateKeyOrPassword`. Use a test-only key/certificate fixture to sign the original sample APK; keep it under `host-tests/src/test/resources` only and never package it into the Android app.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ApkSigningServiceTest'`
Expected: FAIL because production signing is currently tied to the bundled debug key and is not verified against an expected signer.

- [ ] **Step 3: Implement explicit signer service**

Use `ApkSigner` and `ApkVerifier` from the already-declared `com.android.tools.build:apksig:8.7.3`. Validate non-null key/certificate and scheme set, sign to a temporary output, verify expected certificate and schemes, then atomically replace the unsigned temporary artifact. Keep credential objects in-memory only.

- [ ] **Step 4: Remove insecure fallback assets/paths and run tests**

Remove the bundled debug keystore asset and all references to debug passwords/alias or the uber-apk-signer fallback. Run the focused signer class, then `./host-tests/gradlew -p host-tests clean test`.
Expected: only caller-supplied credentials can create a release-signed APK; signing and verification tests pass.

---

### Task 4: Make release/dev status and artifact export fail closed

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/BuildMode.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ArtifactVerification.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/RuntimeCheck.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ReleaseGate.java`
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/ReleaseArtifactPublisher.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java:467-555`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionRequest.java` (from the hybrid-verification plan)
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/model/ProtectionReport.java` (from the hybrid-verification plan)
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/ReleaseGateTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/ReleaseArtifactPublisherTest.java`

**Interfaces:**
- `ReleaseGate.evaluate(BuildMode mode, ArtifactVerification artifact, SignatureVerification originalIdentity, SigningResult signing, SignatureVerification finalSignature, RuntimeCheck runtime) -> ProtectionReport.BuildStatus`.
- `ReleaseArtifactPublisher.publish(Path verifiedArtifact, Path destination, BuildMode mode, ProtectionReport.BuildStatus status) -> Path` accepts `RELEASE_SUCCESS` only for `RELEASE`; `DEV_SUCCESS` or `PROTECTION_PARTIAL` only for explicitly requested `DEVELOPMENT`; failed/unverified status is never published.
- `ProtectionRequest` carries explicit `BuildMode` and an optional transient `ApkSigningConfig`; release mode requires caller-supplied credentials, while development mode may omit them.
- `BuildMode` is `RELEASE` or `DEVELOPMENT`; legacy `signApk=true` maps to release and requires a supplied signer, while the explicit legacy `signApk=false` maps only to unsigned development output and can never mean release.
- `RELEASE` requires source APK signer identity match, successful signing, final signature verification, artifact integrity, and runtime `PASS`; missing/false/exception blocks release export. `DEVELOPMENT` still requires structural artifact integrity but does not claim signer identity, runtime, or release success.

- [ ] **Step 1: Write failing release-state tests**

Add `releaseFailsWhenSigningMissing`, `releaseFailsWhenContainerVerificationFails`, `releaseFailsWhenOriginalSignerIdentityMismatches`, `releaseFailsWhenFinalSignatureVerificationFails`, `releaseFailsWhenRuntimeUnverified`, `developmentIsNeverReleaseSuccess`, and `successfulReleaseRequiresAllGates`. Add publisher tests `refusesFailedOrUnverifiedStatus`, `partialCannotPublishAsRelease`, `publishesExplicitDevelopmentPartialWithNonReleaseName`, and `publishesReleaseOnlyAfterAllGates`. Assert no failed/blocked release copies an artifact to the requested output path.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*ReleaseGateTest' --tests '*ReleaseArtifactPublisherTest'`
Expected: FAIL because verification errors are logged and signing failure can continue to export.

- [ ] **Step 3: Implement explicit state machine and pre-export gate**

Evaluate artifact, original signer identity, requested signing, final signature verification, and runtime status before copying output. Route copies only through `ReleaseArtifactPublisher`; preserve the legacy callback shape while supplying typed report through the additive callback; never send release success for a failed, blocked, or partial release. A compatibility-safe partial artifact is publishable only in explicit development mode with a non-release filename/report status.

- [ ] **Step 4: Run focused and full suites**

Run the two focused classes, then `./host-tests/gradlew -p host-tests clean test`.
Expected: every gate permutation has one deterministic status; failed release outputs are not exported.

---

### Task 5: Add Android runtime gate contract and integration fixture

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/RuntimeSmokeRunner.java`
- Create: `app/src/androidTest/java/com/dex2cpro/TUFAN/engine/security/ProtectionRuntimeSmokeTest.kt`
- Modify: `app/build.gradle` (instrumentation test runner/dependencies only if absent)
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/ReleaseGate.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/RuntimeSmokeGateTest.java`

**Interfaces:**
- `RuntimeSmokeRunner.run(Path signedApk, Set<String> requiredAbis) -> RuntimeCheck` returns `PASS`, `FAIL`, or `UNVERIFIED` with bounded reason codes.
- Release gate requires `PASS`; `UNVERIFIED` must block `RELEASE_SUCCESS`.
- Instrumentation fixture installs/launches the generated sample and exercises one C++, one VM, and one Java-fallback method plus JNI/helper initialization without changing manifest identity.

- [ ] **Step 1: Write failing host gate tests**

Add `missingRunnerReturnsUnverified`, `runnerFailureBlocksRelease`, `runtimePassAllowsNextGate`, and `hostSuiteDoesNotPretendAndroidPass`. Assert a missing runner can never be coerced to `PASS`.

- [ ] **Step 2: Run tests to verify they fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*RuntimeSmokeGateTest'`
Expected: FAIL because no runtime-runner contract currently exists.

- [ ] **Step 3: Implement fail-closed runner interface and Android fixture**

Add the typed runner result and instrumentation fixture. Do not inject a device identifier or claim the test passed where no Android runner is configured. Keep all host tests independent of `androidTest`.

- [ ] **Step 4: Run available checks and record unavailable Android gate**

Run: `./host-tests/gradlew -p host-tests clean test`. Attempt the documented `./gradlew :app:connectedDebugAndroidTest` only when SDK/device tooling is present; otherwise report the exact missing prerequisite and keep release status `UNVERIFIED`.
Expected: host suite passes; Android release remains blocked until the instrumentation matrix actually passes on API 24 and a current supported API for every packaged ABI.

---

## Completion Gate

Release-integrity implementation is complete only when all host tests pass, explicit signer and certificate verification work, APK invariants are checked before export, and failed mandatory gates cannot export a release artifact. A source ZIP or host-only run is not proof of Android installability; without the configured API/ABI runtime matrix, report release status as `UNVERIFIED`.
