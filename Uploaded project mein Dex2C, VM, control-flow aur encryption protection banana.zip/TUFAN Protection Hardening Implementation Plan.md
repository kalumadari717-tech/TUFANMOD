# TUFAN Protection Hardening Implementation Plan

> **For agentic workers:** Use the native session implementation path; complete tasks in order, test-first for behavior changes, and review each task before proceeding. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace weak or misleading parts of the supplied Android protection pipeline with authenticated per-build string encryption, a real semantics-preserving VM control-flow transformation, truthful fail-closed execution/reporting, and reproducible host tests.

**Architecture:** Keep the existing conservative DEX-to-C++ and VM strategy, strengthen the shared TKS AES-GCM envelope parser, route string literals through a versioned TKS envelope, and transform only validated VM programs. Preserve explicit fallback behavior for unsupported DEX, and distinguish authenticated payload tamper checks from whole-APK integrity. The host test project becomes independently runnable; no Android build/runtime success is claimed without Android tooling.

**Tech Stack:** Java 17, JUnit 4, Gradle Wrapper 8.10.2 for standalone host-tests, existing C++17 host parity tests, Android JNI source generation.

**Spec:** `docs/superpowers/specs/2026-10-20-tufan-protection-hardening-design.md`

## Global Constraints

- Maintain minSdk 24, targetSdk 28, Java 17, and existing user-selected ABI behavior.
- Use cryptographically random per-output 32-byte key material; never log it or use a deterministic fallback key.
- AES-GCM uses `AES/GCM/NoPadding`, a fresh 12-byte nonce, and a 128-bit authentication tag; invalid/tampered protected payloads must fail closed.
- Unsupported DEX remains explicit fallback; do not increase REAL counts unless executable C++/VM output exists.
- VM hardening applies only to validated programs and preserves semantics; no anti-debugging, anti-emulator/VM detection, stealth, or evasion features.
- Local payload encryption is not key secrecy from the APK owner and is not whole-APK integrity verification.
- The provided ZIP contains no Git metadata; do not assume commits are possible. Deliver an updated project folder and ZIP after execution and fresh verification.
- The bundled debug signing key is used for output APK signing; signing workflow is outside this plan and is a production blocker until separately replaced with user-controlled signing credentials.

## Review Focus

- Truncated or attacker-sized envelope lengths must fail before dangerous allocations; `TksEnvelopeTest` covers short headers, inconsistent lengths, trailing bytes, and wrong key/context.
- Tampered, missing-key, or malformed string ciphertext must not silently return ciphertext or plaintext; `TksStringEnvelopeTest` and generated JNI-source tests pin the rejection behavior.
- Forward/backward branches, conditional fall-through, loops, and switch fan-out must remain semantically identical after block relocation; `TksControlFlowHardenerTest` compares VM execution before and after.
- JNI must not clear authentication/manifest exceptions and return a default primitive value; `NativeWrapperWriterRuntimeFailureTest` inspects generated failure paths and requires pending exceptions to propagate.
- Unsupported opcodes and placeholder integrity checks must not be counted or described as protected; `DexFailClosedTranslationTest` plus backend-accounting and native-source tests pin the boundary.

---

### Task 1: Restore an isolated, reproducible host test command

**Files:**
- Create: `host-tests/settings.gradle`
- Create: `host-tests/gradle/wrapper/gradle-wrapper.properties`
- Create: `host-tests/gradle/wrapper/gradle-wrapper.jar`
- Create: `host-tests/gradlew`
- Create: `host-tests/gradlew.bat`
- Modify: `host-tests/build.gradle`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/DexToCppTranslator.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/DexArrayDataFailClosedTest.java`

**Interfaces:**
- Produces: repository-local command `./host-tests/gradlew -p host-tests test` from the project root; the `host-tests` build resolves only the standalone Java/JUnit host suite and existing source paths under `../app`.

- [x] **Step 1: Configure an isolated host-test Gradle project**

Create `host-tests/settings.gradle` with root project name `Dex2cPRO-host-tests`; pin the wrapper distribution to Gradle `8.10.2`. Declare Maven Central in the standalone host-test project so dexlib2, Guava, and JUnit resolve without the absent root settings. Keep the existing Java 17 release target and JUnit 4.13.2. Add `TksEnvelope.java`, `TksMethodEnvelope.java`, `TksBuildManifest.java`, `TksStringEnvelope.java`, `NativeNames.java`, `SmaliPatcher.java`, and `NativeWrapperWriter.java` to the selected main source set as their test tasks land.

- [x] **Step 2: Add the official Gradle wrapper files**

Generate the wrapper scripts/JAR for the pinned Gradle distribution and make `host-tests/gradlew` executable. Do not add Android Gradle plugins or require an Android SDK for host tests.

- [x] **Step 3: Run the untouched host suite**

Run: `./host-tests/gradlew -p host-tests test`
The first run exposed a pre-existing reference to nonexistent `Opcode.FILL_ARRAY_DATA_PAYLOAD` in dexlib2 2.5.2. Add the fail-closed regression test for `FILL_ARRAY_DATA`, replace the invalid payload constant with dexlib2's `Opcode.ARRAY_PAYLOAD`, then rerun the full baseline. Expected: the unsupported array-data method remains declined and the host suite reports `BUILD SUCCESSFUL`.

---

### Task 2: Bound and test authenticated envelope parsing

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/TksEnvelope.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/TksMethodEnvelope.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/TksEnvelopeTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/TksMethodEnvelopeTest.java`
- Modify: `host-tests/build.gradle`

**Interfaces:**
- Consumes: `TksEnvelope.seal(byte[] plaintext, byte[] masterKey, String context) -> byte[]` and `TksEnvelope.open(byte[] envelope, byte[] masterKey, String context) -> byte[]`.
- Produces: same v1 API/valid envelope format; all invalid input raises `SecurityException` without unchecked attacker-sized allocation.

- [x] **Step 1: Write failing parser and authentication tests**

Add JUnit tests named `roundTripsAuthenticatedPayload`, `usesFreshNonceForSameInput`, `rejectsWrongKey`, `rejectsWrongContext`, `rejectsTamperedCiphertext`, `rejectsTruncatedHeader`, `rejectsInconsistentCiphertextLengthBeforeAllocation`, `rejectsTrailingBytes`, and `rejectsMalformedMethodPayloadLength`. Assert valid plaintext equality, ciphertext variation for two seals, and `SecurityException` for each invalid case.

- [x] **Step 2: Run the tests to verify the missing cases fail**

Run: `./host-tests/gradlew -p host-tests test --tests '*TksEnvelopeTest' --tests '*TksMethodEnvelopeTest'`
Expected: the existing round-trip behavior passes where already implemented; at least malformed-length/allocation-safety regression cases fail for the expected reason before parser changes.

- [x] **Step 3: Harden `TksEnvelope.open` parsing**

Validate null/empty envelope, key size, context, minimum fixed header, lengths, arithmetic overflow, and exact remaining byte count before allocating ciphertext. In `TksMethodEnvelope.open`, validate the plaintext header length before reading fields and ensure the declared word count matches the remaining byte count without overflow. Preserve the v1 wire format and authenticated AAD. Normalize malformed input to `SecurityException` without swallowing JVM fatal errors such as `OutOfMemoryError`.

- [x] **Step 4: Run focused and full host tests**

Run the focused command above, then `./host-tests/gradlew -p host-tests test`.
Expected: all envelope negative cases fail closed and the full host suite is green.

---

### Task 3: Replace AES-ECB strings and remove key fallbacks

**Files:**
- Create: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/TksStringEnvelope.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcher.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/TksStringEnvelopeTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/SmaliPatcherStringEncryptionTest.java`
- Modify: `host-tests/build.gradle`

**Interfaces:**
- Produces: `TksStringEnvelope.seal(String plaintext, byte[] key) -> String` and `TksStringEnvelope.open(String encoded, byte[] key) -> String`; envelope context is the fixed domain `T-KainShield|string|v1`, with envelope bytes encoded as Base64 for smali literals.
- `SmaliPatcher.patch(Path decompiledDir, List<MethodInfo> methods, String nativeModule, byte[] buildKey)` accepts the exact 32-byte per-output key; missing/invalid key is an error.
- Generated `D2cString.d(String)` uses the same TKS envelope/KDF/AAD and per-output key as build-time sealing; it must throw `SecurityException` on failure, not return the encoded value.

- [x] **Step 1: Write failing string-envelope and smali transformation tests**

Add tests named `stringRoundTripsWithPerBuildKey`, `samePlaintextGetsDifferentCiphertext`, `rejectsWrongKeyAndTampering`, `rejectsMissingKeyInsteadOfUsingFallback`, and `patchedConstStringContainsOnlyAuthenticatedEnvelope`. Use a real temporary smali file and assert the original string is absent, the helper invocation is present, and the envelope can be opened with the supplied build key.

- [x] **Step 2: Run focused tests to verify they fail for current ECB/fallback behavior**

Run: `./host-tests/gradlew -p host-tests test --tests '*TksStringEnvelopeTest' --tests '*SmaliPatcherStringEncryptionTest'`
Expected: tests expose the fixed ECB transformation, fixed fallback, and non-authenticated encoding before implementation.

- [x] **Step 3: Implement versioned string envelopes**

Implement the wrapper using `TksEnvelope` with a domain-separated context. Remove `AES/ECB/PKCS5Padding`, `TKainShld-AES128`, and mutable `ThreadLocal` key fallback. Pass the exact 32-byte build key explicitly from `ProtectionEngine` through patching and generated JNI source; avoid shared mutable static key state.

- [x] **Step 4: Make generated native string decryption match the envelope**

Generate the string JNI helper from the same envelope parsing and AES-GCM decryption routines used by the method bridge. Validate Base64, envelope bounds, context, GCM authentication, and UTF-8 construction. Propagate Java/JNI security exceptions; remove the behavior that returns the original Base64 input after a decryption error. Remove default key material from wrapper generation.

- [x] **Step 5: Run focused, generated-source, and full host tests**

Run the two focused test classes, then `./host-tests/gradlew -p host-tests test`.
Expected: Java envelope round trips/tamper rejection pass; generated JNI source uses AES-GCM and contains no ECB or fixed fallback key; all host tests pass.

---

### Task 4: Replace the cosmetic VM predicate with real block-layout hardening

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/security/vm/TksControlFlowHardener.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/vm/TksControlFlowHardenerTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/security/vm/TksControlFlowHardenerNativeParityTest.java`

**Interfaces:**
- Retain `TksControlFlowHardener.harden(TksProgram program, int buildSeed) -> TksProgram`.
- Consumes: validated one-word TKS instructions with existing jump, conditional-jump, and return semantics; the VM compiler continues to derive `buildSeed` from per-build key plus method signature.
- Produces: a copied, seed-permuted basic-block layout with every branch remapped and explicit fall-through transfers where needed; malformed branch targets are rejected.

- [x] **Step 1: Write failing semantic and seed tests**

Add Java tests named `sameInputAndSeedProduceSameLayout`, `differentSeedsChangeMultiBlockLayout`, `preservesForwardAndBackwardBranches`, `preservesConditionalFallThrough`, `preservesSwitchFanOutAndDefaultPath`, `doesNotMutateInputProgram`, and `rejectsMalformedTargets`. In `TksControlFlowHardenerNativeParityTest`, feed the same original and hardened VM words to the existing host C++ VM harness. For valid fixtures, assert both Java and C++ results match the original program for every input vector used by the fixture.

- [x] **Step 2: Run the hardener tests and verify expected failures**

Run: `./host-tests/gradlew -p host-tests test --tests '*TksControlFlowHardenerTest' --tests '*TksControlFlowHardenerNativeParityTest'`
Expected: existing implementation fails the layout-variation assertions because it only inserts the fixed five-word predicate.

- [x] **Step 3: Implement deterministic block discovery and relocation**

Partition the validated program at entry, branch targets, and instructions after control-transfer terminators. Permute blocks with a deterministic PRNG initialized from `buildSeed`; rewrite all branch targets; emit explicit jumps to preserve fall-through. Keep return blocks terminal and reject unsupported/malformed layouts rather than emitting partial output.

- [x] **Step 4: Run focused semantic parity and full host tests**

Run: `./host-tests/gradlew -p host-tests test --tests '*TksControlFlowHardenerTest' --tests '*TksControlFlowHardenerNativeParityTest'`, then `./host-tests/gradlew -p host-tests test`.
Expected: all parity/seed assertions pass with no existing VM/compiler test regressions.

---

### Task 5: Make runtime failures and protection accounting truthful

**Files:**
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriter.java`
- Modify: `app/src/main/java/com/dex2cpro/TUFAN/engine/ProtectionEngine.java`
- Modify: `app/src/main/assets/engine/jni/nc/Dex2C.cpp`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/NativeWrapperWriterRuntimeFailureTest.java`
- Test: `host-tests/src/test/java/com/dex2cpro/TUFAN/engine/pipeline/ProtectionAccountingTest.java`

**Interfaces:**
- Produces: `NativeWrapperWriter.getLastBackendCounts() -> BackendCounts(cppMethods, vmMethods, fallbackMethods)`; publish the immutable summary only after the generated wrapper file is successfully written, and include only emitted C++/VM signatures in the fully-native set.
- Runtime decrypt/authentication failures propagate as Java `SecurityException`; no silent default primitive/object return after a failed authenticated open.
- Native startup no longer logs a fixed-probe hash as an integrity verification result. Existing authenticated manifest validation remains specifically labeled payload/build-context validation, not APK integrity.

- [x] **Step 1: Write failing generated-wrapper and accounting tests**

Add `generatedVmWrapperPreservesPendingSecurityException`, `generatedStringDecryptRejectsInsteadOfReturningCiphertext`, `unsupportedMethodIsCountedAsFallback`, `translatedMethodIsCountedOnlyAfterBodyEmission`, `failedWrapperWriteDoesNotPublishNativeCounts`, and `jniOnLoadDoesNotClaimFixedProbeIntegrity`. Assert generated output contains the documented failure behavior and that only fully emitted methods appear in the protected signature/count results.

- [x] **Step 2: Run focused tests and confirm current failures**

Run: `./host-tests/gradlew -p host-tests test --tests '*NativeWrapperWriterRuntimeFailureTest' --tests '*ProtectionAccountingTest'`
Expected: failures identify swallowed JNI exceptions, misleading fixed-probe log, or missing backend separation.

- [x] **Step 3: Implement fail-closed JNI behavior and accurate accounting**

Keep a pending JNI exception intact; if a native bridge fails without setting one, throw `SecurityException` rather than returning a zero/null default. Track C++, VM, and fallback outcomes explicitly and keep the original DEX body for unsupported methods. Remove the `TKS` constant-probe `JNI_OnLoad` digest/log path and its misleading security wording; do not add anti-tamper claims.

- [x] **Step 4: Run focused and full host tests**

Run both focused test classes, then `./host-tests/gradlew -p host-tests test`.
Expected: negative runtime/accounting tests pass and existing DEX fail-closed tests remain green.

---

### Task 6: End-to-end regression checks and delivery validation

**Files:**
- Modify: `docs/superpowers/specs/2026-10-20-tufan-protection-hardening-design.md`
- Modify: `docs/superpowers/plans/2026-10-20-tufan-protection-hardening.md`
- Create: `docs/protection-security-notes.md`
- Test: existing full `host-tests/src/test/java/**` suite plus tests added in Tasks 2–5.

**Interfaces:**
- Produces: a documented, repeatable host verification command, accurate layer limitations, and an updated ZIP of the supplied project.

- [x] **Step 1: Add concise protection/security notes**

Document the implemented layer boundaries, supported-method/fallback reporting, key embedding limitation, supported Android baseline, host-only verification status, and that the bundled shared debug signing key is not production-safe and signing must be replaced before production distribution.

- [x] **Step 2: Run the complete host suite fresh**

Run: `./host-tests/gradlew -p host-tests clean test`
Expected: `BUILD SUCCESSFUL`, zero failed tests, and native-VM parity tests finish within their existing timeouts.

- [x] **Step 3: Run static source checks and inspect final changes**

Run a source scan asserting there is no `AES/ECB/PKCS5Padding`, `TKainShld-AES128`, or `integrity digest ready` string in the active protection path. Inspect generated C++/smali fixture output for GCM, fail-closed JNI, truthful backend counts, and no fixed fallback. Confirm no debug signing key was accidentally copied into a user-facing final report or claim.

- [x] **Step 4: Package the project and verify the archive**

Create `/home/ubuntu/TUFAN_PROTECTION_HARDENED.zip` from the project root after tests pass. Re-open the ZIP listing and verify the wrapper, new security implementation/tests, documentation, and existing project files are present; check no absolute or parent-traversal paths were added.

- [x] **Step 5: Report verified scope and blockers**

State the exact host test counts and command only after fresh output is read. Explicitly state that Android/device execution was not verified without SDK/NDK/device. Explicitly warn that APK outputs signed by the bundled shared debug keystore are not safe for production until a separate user-controlled signing workflow is implemented.
